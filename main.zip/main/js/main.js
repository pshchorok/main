$(function () {
    const ticker = function() {
        setTimeout(function() {
            $('.content li:first').animate({marginLeft: '-100%'}, 600, 'swing', function() {
                $(this).detach().appendTo('ul.content').removeAttr('style');
            });
            ticker();
        }, 4000);
    };
    ticker();


});